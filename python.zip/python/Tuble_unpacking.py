numbers = (10, 20, 30)
a, b, c = numbers
print(f"a = {a}")
print(f"b = {b}")
print(f"c = {c}")