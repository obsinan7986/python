# student_class.py
class Student:
    def __init__(self, name, age, course):
        self.name = name
        self.age = age
        self.course = course
    
    def display_info(self):
        print(f"Name: {self.name}, Age: {self.age}, Course: {self.course}")

def run_student_class():
    student = Student("Alice", 20, "Python")
    student.display_info()