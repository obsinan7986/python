# common_elements.py
def find_common_elements(list1, list2):
    return list(set(list1) & set(list2))

def run_common_elements():
    list1 = [1, 2, 3, 4, 5]
    list2 = [3, 4, 5, 6, 7]
    result = find_common_elements(list1, list2)
    print(f"List1: {list1}")
    print(f"List2: {list2}")
    print(f"Common elements: {result}")