x = 10
y = 3.14
z = "HUCISA"
a = True

print(f"x is {type(x)}")
print(f"y is {type(y)}")
print(f"z is {type(z)}")
print(f"a is {type(a)}")