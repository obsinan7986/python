name = "Blackie"
age = 25
hobby = "Python programming"

print(f"My name is {name}.")
print(f"I am {age} years old.")
print(f"I love {hobby}!")