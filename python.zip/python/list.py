def list_operations(numbers, add_num, remove_num):
    # Original list
    print(f"Original list: {numbers}")
    
    # Add number
    numbers.append(add_num)
    print(f"After adding {add_num}: {numbers}")
    
    # Remove number
    if remove_num in numbers:
        numbers.remove(remove_num)
        print(f"After removing {remove_num}: {numbers}")
    
    # Max and min
    print(f"Maximum value: {max(numbers)}")
    print(f"Minimum value: {min(numbers)}")

numbers = [2, 4, 6, 8, 10]
list_operations(numbers, 12, 4)