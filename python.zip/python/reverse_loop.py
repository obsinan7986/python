def reverse_string(text):
    reversed_str = ""
    for char in text:
        reversed_str = char + reversed_str
    return reversed_str

string = "Hello"
print(f"Original: {string}")
print(f"Reversed: {reverse_string(string)}")