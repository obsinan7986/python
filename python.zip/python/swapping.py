a = 5
b = 10
print(f"Before swap: a = {a}, b = {b}")

a, b = b, a
print(f"After swap: a = {a}, b = {b}")