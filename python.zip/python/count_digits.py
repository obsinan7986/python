# count_digits.py
def count_digits(number):
    # Convert to positive number and string to count digits
    return len(str(abs(number)))

def run_count_digits(number=12345):
    result = count_digits(number)
    print(f"Number {number} has {result} digits")