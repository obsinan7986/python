sum_even = 0
for i in range(1, 101):
    if i % 2 == 0:
        sum_even += i
print(f"Sum of even numbers from 1 to 100: {sum_even}")