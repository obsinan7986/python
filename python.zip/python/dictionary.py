students = {"Alice": 20, "Bob": 21, "Charlie": 19}

# Add new student
students["David"] = 22
print(f"After adding David: {students}")

# Update age
students["Alice"] = 21
print(f"After updating Alice's age: {students}")

# Remove student
del students["Bob"]
print(f"After removing Bob: {students}")