# course_inheritance.py
class Course:
    def get_details(self):
        return "This is a generic course"

class WebDevClass(Course):
    def get_details(self):
        return "This is a Web Development course focusing on HTML, CSS, and JS"

def run_course_inheritance():
    course = Course()
    web_dev = WebDevClass()
    print(course.get_details())
    print(web_dev.get_details())